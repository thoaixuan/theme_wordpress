<div class="ui segment arconfig-panel <?php echo ($activeSubmit == 'ArContactUsConfigLiveChat')? '' : 'hidden' ?>" id="arcontactus-livechat">
    <?php echo $liveChatsConfig->getFormHelper()->render() ?>
</div>