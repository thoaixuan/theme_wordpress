<div class="ui segment arconfig-panel <?php echo ($activeSubmit == 'ArContactUsConfigGeneral' || empty($activeSubmit))? '' : 'hidden' ?>" id="arcontactus-general">
    <?php echo $generalConfig->getFormHelper()->render() ?>
</div>