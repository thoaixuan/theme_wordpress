<div class="ui segment arconfig-panel <?php echo ($activeSubmit == 'ArContactUsConfigMenu')? '' : 'hidden' ?>" id="arcontactus-menu">
    <?php echo $menuConfig->getFormHelper()->render() ?>
</div>