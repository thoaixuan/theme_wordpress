<div class="ui segment arconfig-panel <?php echo ($activeSubmit == 'ArContactUsConfigPrompt')? '' : 'hidden' ?>" id="arcontactus-prompt">
    <?php echo $promptConfig->getFormHelper()->render() ?>
</div>