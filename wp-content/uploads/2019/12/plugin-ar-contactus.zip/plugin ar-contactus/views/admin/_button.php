<div class="ui segment arconfig-panel <?php echo ($activeSubmit == 'ArContactUsConfigButton')? '' : 'hidden' ?>" id="arcontactus-button">
    <?php echo $buttonConfig->getFormHelper()->render() ?>
</div>