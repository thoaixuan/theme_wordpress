<?php echo sprintf(__('Customer requested a callback at %s.', AR_CONTACTUS_TEXT_DOMAIN), date('Y-m-d H:i:s')) ?>
<?php echo sprintf(__('Please call ASAP to %s', AR_CONTACTUS_TEXT_DOMAIN), $phone);